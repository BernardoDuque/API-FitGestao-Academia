package br.com.academia.controller;

import br.com.academia.model.Mensalidade;
import br.com.academia.repository.MensalidadeRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/mensalidades")
@CrossOrigin
public class MensalidadeController {
    private final MensalidadeRepository repository;
    public MensalidadeController(MensalidadeRepository repository) { this.repository = repository; }

    @GetMapping public List<Mensalidade> listar() { return repository.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Mensalidade> buscar(@PathVariable Long id) { return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping public Mensalidade criar(@RequestBody Mensalidade item) { item.setId(null); return repository.save(item); }
    @PutMapping("/{id}") public ResponseEntity<Mensalidade> atualizar(@PathVariable Long id, @RequestBody Mensalidade item) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        item.setId(id); return ResponseEntity.ok(repository.save(item));
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        repository.deleteById(id); return ResponseEntity.noContent().build();
    }
}
