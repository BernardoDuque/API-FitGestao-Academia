package br.com.academia;

import br.com.academia.model.*;
import br.com.academia.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DadosIniciais {
    @Bean
    CommandLineRunner carregarDados(AlunoRepository alunos, PlanoRepository planos,
            MensalidadeRepository mensalidades, ProfessorRepository professores,
            TreinoRepository treinos, AvaliacaoFisicaRepository avaliacoes) {
        return args -> {
            if (planos.count() > 0 || alunos.count() > 0) return;
            Plano essencial = new Plano(); essencial.setNome("Essencial"); essencial.setDescricao("Acesso à musculação"); essencial.setValorMensal(119.90); essencial.setDuracaoDias(30); essencial.setAtivo(true); essencial = planos.save(essencial);
            Plano completo = new Plano(); completo.setNome("Completo"); completo.setDescricao("Musculação e aulas coletivas"); completo.setValorMensal(169.90); completo.setDuracaoDias(30); completo.setAtivo(true); planos.save(completo);
            Aluno ana = new Aluno(); ana.setNome("Ana Souza"); ana.setEmail("ana@email.com"); ana.setTelefone("(11) 99999-0001"); ana.setDataNascimento("1998-04-12"); ana.setPlanoId(essencial.getId()); ana.setDataCadastro("2026-01-10"); ana.setAtivo(true); ana = alunos.save(ana);
            Aluno bruno = new Aluno(); bruno.setNome("Bruno Lima"); bruno.setEmail("bruno@email.com"); bruno.setTelefone("(11) 99999-0002"); bruno.setDataNascimento("1992-09-23"); bruno.setPlanoId(essencial.getId()); bruno.setDataCadastro("2026-02-02"); bruno.setAtivo(true); bruno = alunos.save(bruno);
            Professor prof = new Professor(); prof.setNome("Marcos Oliveira"); prof.setEspecialidade("Musculação e condicionamento"); prof.setEmail("marcos@fitgestao.com"); prof.setTelefone("(11) 98888-1000"); prof.setRegistroProfissional("CREF 012345-G/SP"); prof.setAtivo(true); prof = professores.save(prof);
            Mensalidade mensalidade = new Mensalidade(); mensalidade.setAlunoId(ana.getId()); mensalidade.setReferencia("2026-11"); mensalidade.setVencimento("2026-11-10"); mensalidade.setValor(119.90); mensalidade.setSituacao("VENCIDA"); mensalidades.save(mensalidade);
            Mensalidade paga = new Mensalidade(); paga.setAlunoId(bruno.getId()); paga.setReferencia("2026-11"); paga.setVencimento("2026-11-05"); paga.setValor(119.90); paga.setSituacao("PAGA"); paga.setDataPagamento("2026-11-04"); mensalidades.save(paga);
            Treino treino = new Treino(); treino.setAlunoId(ana.getId()); treino.setProfessorId(prof.getId()); treino.setTitulo("Adaptação A/B"); treino.setDataInicio("2026-11-01"); treino.setDescricao("Plano inicial de adaptação"); treino.setExercicios("A: Leg press 3x12; cadeira extensora 3x12; supino 3x10.\nB: Puxada frontal 3x12; remada 3x10; desenvolvimento 3x12."); treino.setAtivo(true); treinos.save(treino);
            AvaliacaoFisica avaliacao = new AvaliacaoFisica(); avaliacao.setAlunoId(ana.getId()); avaliacao.setDataAvaliacao("2026-11-01"); avaliacao.setPesoKg(64.5); avaliacao.setAlturaCm(165.0); avaliacao.setPercentualGordura(27.0); avaliacao.setObservacoes("Avaliação inicial. Reavaliar em 8 semanas."); avaliacoes.save(avaliacao);
        };
    }
}
