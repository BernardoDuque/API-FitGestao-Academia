package br.com.academia.controller;

import br.com.academia.model.Professor;
import br.com.academia.repository.ProfessorRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/professores")
@CrossOrigin
public class ProfessorController {
    private final ProfessorRepository repository;
    public ProfessorController(ProfessorRepository repository) { this.repository = repository; }

    @GetMapping public List<Professor> listar() { return repository.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Professor> buscar(@PathVariable Long id) { return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping public Professor criar(@RequestBody Professor item) { item.setId(null); return repository.save(item); }
    @PutMapping("/{id}") public ResponseEntity<Professor> atualizar(@PathVariable Long id, @RequestBody Professor item) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        item.setId(id); return ResponseEntity.ok(repository.save(item));
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        repository.deleteById(id); return ResponseEntity.noContent().build();
    }
}
