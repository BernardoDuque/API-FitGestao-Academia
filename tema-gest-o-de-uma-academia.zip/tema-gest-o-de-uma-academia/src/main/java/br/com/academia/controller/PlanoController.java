package br.com.academia.controller;

import br.com.academia.model.Plano;
import br.com.academia.repository.PlanoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/planos")
@CrossOrigin
public class PlanoController {
    private final PlanoRepository repository;
    public PlanoController(PlanoRepository repository) { this.repository = repository; }

    @GetMapping public List<Plano> listar() { return repository.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Plano> buscar(@PathVariable Long id) { return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping public Plano criar(@RequestBody Plano item) { item.setId(null); return repository.save(item); }
    @PutMapping("/{id}") public ResponseEntity<Plano> atualizar(@PathVariable Long id, @RequestBody Plano item) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        item.setId(id); return ResponseEntity.ok(repository.save(item));
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        repository.deleteById(id); return ResponseEntity.noContent().build();
    }
}
