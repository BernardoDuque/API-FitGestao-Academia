package br.com.academia.controller;

import br.com.academia.model.Aluno;
import br.com.academia.repository.AlunoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/alunos")
@CrossOrigin
public class AlunoController {
    private final AlunoRepository repository;
    public AlunoController(AlunoRepository repository) { this.repository = repository; }

    @GetMapping public List<Aluno> listar() { return repository.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Aluno> buscar(@PathVariable Long id) { return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping public Aluno criar(@RequestBody Aluno item) { item.setId(null); return repository.save(item); }
    @PutMapping("/{id}") public ResponseEntity<Aluno> atualizar(@PathVariable Long id, @RequestBody Aluno item) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        item.setId(id); return ResponseEntity.ok(repository.save(item));
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        repository.deleteById(id); return ResponseEntity.noContent().build();
    }
}
