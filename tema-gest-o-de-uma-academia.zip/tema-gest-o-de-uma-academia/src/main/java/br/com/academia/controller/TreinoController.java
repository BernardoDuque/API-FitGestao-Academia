package br.com.academia.controller;

import br.com.academia.model.Treino;
import br.com.academia.repository.TreinoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/treinos")
@CrossOrigin
public class TreinoController {
    private final TreinoRepository repository;
    public TreinoController(TreinoRepository repository) { this.repository = repository; }

    @GetMapping public List<Treino> listar() { return repository.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Treino> buscar(@PathVariable Long id) { return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping public Treino criar(@RequestBody Treino item) { item.setId(null); return repository.save(item); }
    @PutMapping("/{id}") public ResponseEntity<Treino> atualizar(@PathVariable Long id, @RequestBody Treino item) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        item.setId(id); return ResponseEntity.ok(repository.save(item));
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        repository.deleteById(id); return ResponseEntity.noContent().build();
    }
}
