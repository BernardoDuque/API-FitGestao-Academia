package br.com.academia.repository;

import br.com.academia.model.AvaliacaoFisica;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AvaliacaoFisicaRepository extends JpaRepository<AvaliacaoFisica, Long> {}
