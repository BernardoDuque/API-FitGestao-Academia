package br.com.academia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FitGestaoApplication {
    public static void main(String[] args) { SpringApplication.run(FitGestaoApplication.class, args); }
}
