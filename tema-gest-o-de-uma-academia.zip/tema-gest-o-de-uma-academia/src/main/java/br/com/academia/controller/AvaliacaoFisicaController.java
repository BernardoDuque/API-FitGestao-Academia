package br.com.academia.controller;

import br.com.academia.model.AvaliacaoFisica;
import br.com.academia.repository.AvaliacaoFisicaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/avaliacoes")
@CrossOrigin
public class AvaliacaoFisicaController {
    private final AvaliacaoFisicaRepository repository;
    public AvaliacaoFisicaController(AvaliacaoFisicaRepository repository) { this.repository = repository; }

    @GetMapping public List<AvaliacaoFisica> listar() { return repository.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<AvaliacaoFisica> buscar(@PathVariable Long id) { return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build()); }
    @PostMapping public AvaliacaoFisica criar(@RequestBody AvaliacaoFisica item) { item.setId(null); return repository.save(item); }
    @PutMapping("/{id}") public ResponseEntity<AvaliacaoFisica> atualizar(@PathVariable Long id, @RequestBody AvaliacaoFisica item) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        item.setId(id); return ResponseEntity.ok(repository.save(item));
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        repository.deleteById(id); return ResponseEntity.noContent().build();
    }
}
