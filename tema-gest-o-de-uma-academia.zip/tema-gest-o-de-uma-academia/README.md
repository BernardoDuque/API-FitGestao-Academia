# FitGestão — Sistema de Gestão de Academia

Projeto acadêmico com back-end Java/Spring Boot, banco H2 e front-end responsivo servido pelo próprio Spring Boot. A interface usa `fetch` para consumir a API REST; os cadastros são persistidos no banco local `./data/fitgestao`.

## Abrir no IntelliJ IDEA

1. Abra a pasta do projeto pelo IntelliJ IDEA e aguarde a importação do `pom.xml` como projeto Maven.
2. Configure um JDK 17 ou superior (o projeto também pode rodar com Java 25).
3. Execute `FitGestaoApplication` em `src/main/java/br/com/academia/FitGestaoApplication.java`.
4. Acesse [http://localhost:8080](http://localhost:8080).

Também é possível iniciar pelo terminal com `mvn spring-boot:run`, se o Maven estiver instalado. O primeiro início cria exemplos de planos, alunos, professor, mensalidades, treino e avaliação física. Os dados permanecem no banco H2 local; use “Excluir” na interface para remover registros.

## Módulos incluídos

- **Alunos:** cadastro, consulta, edição e exclusão, com vínculo a plano.
- **Planos:** cadastro e controle de disponibilidade e valor.
- **Mensalidades:** cadastro, consulta e atualização da situação (pendente, paga ou vencida), com data de pagamento.
- **Professores:** cadastro e consulta da equipe.
- **Treinos:** fichas por aluno com professor, exercícios e séries.
- **Avaliações físicas:** registro de peso, altura, percentual de gordura e observações.

Todos os módulos oferecem operações REST de listar, consultar por ID, cadastrar, editar e excluir. Os dados de exemplo são carregados apenas quando o banco ainda não contém planos nem alunos.

## API

| Recurso | Rota |
| --- | --- |
| Alunos | `/api/alunos` |
| Planos | `/api/planos` |
| Mensalidades | `/api/mensalidades` |
| Professores | `/api/professores` |
| Treinos | `/api/treinos` |
| Avaliações físicas | `/api/avaliacoes` |

A API aceita JSON. O console do H2 fica disponível em `/h2-console` durante o desenvolvimento, com JDBC URL `jdbc:h2:file:./data/fitgestao`, usuário `sa` e senha vazia.
